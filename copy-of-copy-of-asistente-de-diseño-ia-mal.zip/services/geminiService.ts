/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
*/

import { GoogleGenAI, GenerateContentResponse, Modality, Type } from "@google/genai";
import { Product, ProductAnalysis, StyleGenerationMode } from "../types";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY! });

const fileToPart = async (file: File) => {
    const dataUrl = await new Promise<string>((resolve, reject) => {
        const reader = new FileReader();
        reader.readAsDataURL(file);
        reader.onload = () => resolve(reader.result as string);
        reader.onerror = error => reject(error);
    });
    const arr = dataUrl.split(',');
    const mimeType = arr[0].match(/:(.*?);/)?.[1];
    const data = arr[1];
    if (!mimeType || !data) throw new Error("Could not parse data URL.");
    return { inlineData: { mimeType, data } };
};

const safelyParseJson = (jsonString: string) => {
    try {
        const cleanedString = jsonString.replace(/^```json\s*|```\s*$/g, '').trim();
        return JSON.parse(cleanedString);
    } catch (e) {
        console.error("Failed to parse JSON:", jsonString);
        throw new Error("La IA devolvió una respuesta con formato incorrecto. Por favor, inténtalo de nuevo.");
    }
};

/**
 * Normalizes a filename for robust matching by removing the extension and converting to lowercase.
 * @param filename The filename to normalize.
 * @returns The normalized filename.
 */
const normalizeFilename = (filename: string) => {
    if (!filename) return '';
    const parts = filename.split('.');
    if (parts.length > 1) {
        parts.pop(); // Remove extension
    }
    return parts.join('.').toLowerCase();
};


/**
 * AI recommends a style and analyzes products against it.
 */
export const recommendStyleAndAnalyzeProducts = async (sceneFile: File, products: Product[]): Promise<{ recommendedStyle: string, analyzedProducts: ProductAnalysis[] }> => {
    const scenePart = await fileToPart(sceneFile);
    const productParts = await Promise.all(products.map(p => fileToPart(p.file)));

    const prompt = `
Actúa como un diseñador de interiores experto. Te proporcionaré una imagen de una escena y varias imágenes de productos.
Tu tarea tiene dos partes:
1.  **Recomendar un Estilo:** Basándote en la escena y los productos, recomienda el estilo de decoración más adecuado (ej. Moderno, Minimalista, Bohemio, etc.).
2.  **Analizar Productos:** Evalúa cada producto para ver qué tan bien encaja con el estilo que recomendaste.

Devuelve tu respuesta en formato JSON con la siguiente estructura:
{
  "recommendedStyle": "El estilo que recomiendas",
  "productAnalyses": [
    {
      "productName": "nombre_del_archivo_del_producto.jpg",
      "verdict": "good" | "bad" | "neutral",
      "reason": "Una breve explicación de por qué diste ese veredicto.",
      "recommendation": "Un consejo útil para el usuario sobre este producto."
    }
  ]
}
Asegúrate de que 'productName' coincida exactamente con el nombre de archivo de cada producto. Incluye un análisis para cada producto proporcionado.
`;
    
    const allParts = [
        { text: prompt },
        scenePart,
        ...productParts
    ];

    const response = await ai.models.generateContent({
        model: 'gemini-2.5-flash',
        contents: { parts: allParts },
        config: { responseMimeType: 'application/json' }
    });

    const result = safelyParseJson(response.text);

    const analyzedProducts = products.map(p => {
        const normalizedProductName = normalizeFilename(p.name);
        const analysis = result.productAnalyses.find((a: any) => normalizeFilename(a.productName) === normalizedProductName);
        return { ...p, analysis: analysis || null };
    });

    return {
        recommendedStyle: result.recommendedStyle,
        analyzedProducts
    };
};

/**
 * Validates products against a user-selected style.
 */
export const validateStyleForProduct = async (sceneFile: File, products: Product[], style: string): Promise<ProductAnalysis[]> => {
    const scenePart = await fileToPart(sceneFile);
    const productParts = await Promise.all(products.map(p => fileToPart(p.file)));

    const prompt = `
Actúa como un diseñador de interiores experto. Te proporcionaré una imagen de una escena, varias imágenes de productos y un estilo de decoración específico: "${style}".
Tu tarea es evaluar cada producto para ver qué tan bien encaja con el estilo "${style}" en el contexto de la escena proporcionada.

Devuelve tu respuesta en formato JSON como un array con la siguiente estructura:
[
    {
      "productName": "nombre_del_archivo_del_producto.jpg",
      "verdict": "good" | "bad" | "neutral",
      "reason": "Una breve explicación de por qué diste ese veredicto en relación con el estilo ${style}.",
      "recommendation": "Un consejo útil para el usuario para integrar mejor este producto en el estilo ${style}."
    }
]
Asegúrate de que 'productName' coincida exactamente con el nombre de archivo de cada producto. Incluye un análisis para cada producto proporcionado.
`;
    
    const allParts = [
        { text: prompt },
        scenePart,
        ...productParts
    ];

    const response = await ai.models.generateContent({
        model: 'gemini-2.5-flash',
        contents: { parts: allParts },
        config: { responseMimeType: 'application/json' }
    });

    const result = safelyParseJson(response.text);

    return products.map(p => {
        const normalizedProductName = normalizeFilename(p.name);
        const analysis = result.find((a: any) => normalizeFilename(a.productName) === normalizedProductName);
        return { ...p, analysis: analysis || null };
    });
};


interface GenerationParams {
    sceneFile: File;
    products: Product[];
    numberOfVersions: number;
    styleGenerationMode: StyleGenerationMode;
    versionStyles: { [key: number]: string };
}

/**
 * Generates the final scene with selected products.
 */
export const generateFinalScene = async (params: GenerationParams): Promise<string[]> => {
    const { sceneFile, products, numberOfVersions, styleGenerationMode, versionStyles } = params;

    const generationPromises = [];

    for (let i = 0; i < numberOfVersions; i++) {
        const scenePart = await fileToPart(sceneFile);
        const productParts = await Promise.all(products.map(p => fileToPart(p.file)));

        let styleInstruction = "Integra los productos en la escena de la forma más fotorrealista posible, prestando especial atención a la escala, perspectiva, iluminación y sombras. Sé creativo con la composición.";
        if (styleGenerationMode === 'specific-styles') {
            styleInstruction = `Integra los productos en la escena de forma fotorrealista, siguiendo un estilo de decoración '${versionStyles[i]}'. Presta atención a la escala, perspectiva, iluminación y sombras para que coincidan con el estilo ${versionStyles[i]}.`;
        }

        const prompt = `
**Rol:** Eres un experto en composición visual y diseño de interiores.
**Tarea:** Integra los 'productos' proporcionados en la 'escena' de manera fotorrealista.

**Imágenes:**
-   La primera imagen es la 'escena'.
-   Las siguientes imágenes son los 'productos' a colocar.

**Instrucción Clave:** ${styleInstruction}

**Requisitos:**
-   El resultado debe ser una única imagen de alta calidad.
-   No añadas texto ni explicaciones. Solo la imagen final.
-   Asegúrate de que los productos se vean naturales en el entorno.
`;

        const allParts = [scenePart, ...productParts, { text: prompt }];

        const promise = ai.models.generateContent({
            model: 'gemini-2.5-flash-image-preview',
            contents: { parts: allParts },
            config: {
                responseModalities: [Modality.IMAGE],
            },
        }).then(response => {
            const imagePart = response.candidates?.[0]?.content?.parts?.find(part => part.inlineData);
            if (imagePart?.inlineData) {
                const { mimeType, data } = imagePart.inlineData;
                return `data:${mimeType};base64,${data}`;
            }
            throw new Error(`La IA no devolvió una imagen para la versión ${i + 1}.`);
        });

        generationPromises.push(promise);
    }

    return Promise.all(generationPromises);
};