/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
*/

import React, { useState, useCallback, useEffect } from 'react';
import { recommendStyleAndAnalyzeProducts, validateStyleForProduct, generateFinalScene } from './services/geminiService';
import { ProductAnalysis, AppStep, AnalysisMode, ProductSelectionMode, StyleGenerationMode } from './types';
import Header from './components/Header';
import ImageUploader from './components/ImageUploader';
import ObjectCard from './components/ObjectCard';
import Spinner from './components/Spinner';

const DESIGN_STYLES = ['Moderno', 'Minimalista', 'Bohemio', 'Industrial', 'Costero', 'Rústico', 'Ecléctico'];

const App: React.FC = () => {
  const [currentStep, setCurrentStep] = useState<AppStep>('upload');
  const [sceneFile, setSceneFile] = useState<File | null>(null);
  const [catalog, setCatalog] = useState<ProductAnalysis[]>([]);
  const [selectedProductIds, setSelectedProductIds] = useState<Set<string>>(new Set());
  
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [loadingMessage, setLoadingMessage] = useState<string>('');
  const [error, setError] = useState<string | null>(null);
  
  // Analysis state
  const [analysisMode, setAnalysisMode] = useState<AnalysisMode>(null);
  const [selectedStyle, setSelectedStyle] = useState<string>(DESIGN_STYLES[0]);
  const [recommendedStyle, setRecommendedStyle] = useState<string>('');

  // Generation state
  const [numberOfVersions, setNumberOfVersions] = useState<number>(1);
  const [productSelectionMode, setProductSelectionMode] = useState<ProductSelectionMode>('manual');
  const [styleGenerationMode, setStyleGenerationMode] = useState<StyleGenerationMode>('creative-ai');
  const [versionStyles, setVersionStyles] = useState<{[key: number]: string}>({});
  const [showAiConfirmModal, setShowAiConfirmModal] = useState<boolean>(false);

  // Results state
  const [finalImages, setFinalImages] = useState<string[]>([]);

  const sceneUrl = sceneFile ? URL.createObjectURL(sceneFile) : null;
  const areUploadsComplete = sceneFile && catalog.length > 0;

  // Effect to clean up blob URLs
  useEffect(() => {
    // Only sceneUrl uses a blob URL that needs revoking.
    // Catalog and final images use data URLs which are garbage collected.
    return () => {
      if (sceneUrl) {
        URL.revokeObjectURL(sceneUrl);
      }
    };
  }, [sceneUrl]);

  // Effect to sync version-specific style selections
  useEffect(() => {
    const newVersionStyles: {[key: number]: string} = {};
    for (let i = 0; i < numberOfVersions; i++) {
        newVersionStyles[i] = versionStyles[i] || DESIGN_STYLES[0];
    }
    setVersionStyles(newVersionStyles);
  }, [numberOfVersions]);


  const handleSceneUpload = (files: File[]) => {
    if (!files || files.length === 0) return;
    setError(null);
    setSceneFile(files[0]);
  };

  const handleProductUpload = (files: File[]) => {
    setError(null);
    const newProductsPromises = files.map(file => 
        new Promise<ProductAnalysis>((resolve, reject) => {
            const reader = new FileReader();
            reader.onload = () => resolve({
                id: `${file.name}-${Date.now()}-${Math.random()}`,
                name: file.name,
                file: file,
                imageUrl: reader.result as string
            });
            reader.onerror = (error) => reject(error);
            reader.readAsDataURL(file);
        })
    );

    Promise.all(newProductsPromises)
        .then(newProducts => {
            setCatalog(prev => [...prev, ...newProducts]);
        })
        .catch(error => {
            console.error("Error processing uploaded files:", error);
            setError("Hubo un error al cargar algunas imágenes.");
        });
  };

  const handleProductSelect = (productId: string) => {
    setSelectedProductIds(prev => {
      const newSet = new Set(prev);
      if (newSet.has(productId)) {
        newSet.delete(productId);
      } else {
        newSet.add(productId);
      }
      return newSet;
    });
  };

  const handleStartAnalysis = async (mode: AnalysisMode) => {
    if (!mode || !sceneFile || catalog.length === 0) {
      setError('Por favor, sube una escena y al menos un producto.');
      return;
    }
    
    setIsLoading(true);
    setLoadingMessage('Analizando compatibilidad de estilos...');
    setError(null);

    try {
      let analysisResults: ProductAnalysis[] = [];
      if (mode === 'ai-recommends') {
        const result = await recommendStyleAndAnalyzeProducts(sceneFile, catalog);
        setRecommendedStyle(result.recommendedStyle);
        analysisResults = result.analyzedProducts;
      } else { // user-validates
        analysisResults = await validateStyleForProduct(sceneFile, catalog, selectedStyle);
        setRecommendedStyle(''); // Clear recommended style
      }
      setCatalog(analysisResults);
      setCurrentStep('analyze');
    } catch (err) {
      const message = err instanceof Error ? err.message : 'Ocurrió un error desconocido durante el análisis.';
      setError(`Error en el análisis: ${message}`);
      console.error(err);
    } finally {
      setIsLoading(false);
    }
  };

  const handleGenerateFinalImage = async () => {
    if (!sceneFile) return;
    setError(null);
    
    let productsToGenerate: ProductAnalysis[] = [];
    if (productSelectionMode === 'manual') {
        productsToGenerate = catalog.filter(p => selectedProductIds.has(p.id));
        if (productsToGenerate.length === 0) {
            setError('Por favor, selecciona manualmente al menos un producto para generar.');
            return;
        }
    } else { // 'ai'
        productsToGenerate = catalog.filter(p => p.analysis?.verdict === 'good');
        if (productsToGenerate.length === 0) {
            setError('La IA no ha calificado ningún producto como "BUENA IDEA". Por favor, selecciona los productos manualmente.');
            return;
        }
    }

    setIsLoading(true);
    setLoadingMessage('Generando diseños fotorrealistas...');

    try {
        const images = await generateFinalScene({
            sceneFile,
            products: productsToGenerate,
            numberOfVersions,
            styleGenerationMode,
            versionStyles,
        });
        setFinalImages(images);
        setCurrentStep('results');
    } catch (err) {
        const message = err instanceof Error ? err.message : 'Ocurrió un error desconocido durante la generación.';
        setError(`Error en la generación: ${message}`);
        console.error(err);
    } finally {
        setIsLoading(false);
    }
  };

  const handleGenerationClick = () => {
    if (productSelectionMode === 'ai') {
      const hasGoodProducts = catalog.some(p => p.analysis?.verdict === 'good');
      if (!hasGoodProducts) {
        setError('La IA no ha calificado ningún producto como "BUENA IDEA". Por favor, selecciona los productos manualmente.');
        return;
      }
      setShowAiConfirmModal(true);
    } else {
      handleGenerateFinalImage();
    }
  };

  const handleReset = () => {
    setCurrentStep('upload');
    setSceneFile(null);
    setCatalog([]);
    setSelectedProductIds(new Set());
    setError(null);
    setIsLoading(false);
    setFinalImages([]);
    setAnalysisMode(null);
    setRecommendedStyle('');
  };

  const renderUploadStep = () => (
    <div className="w-full animate-fade-in">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-8">
        <ImageUploader id="scene-uploader" label="Paso 1: Sube tu Escena" onFileSelect={handleSceneUpload} imageUrl={sceneUrl} />
        <ImageUploader id="product-uploader" label="Paso 2: Sube tus Productos" onFileSelect={handleProductUpload} imageUrl={null} allowMultiple />
      </div>

       {catalog.length > 0 && (
        <div className="mb-8">
            <h3 className="text-xl font-semibold text-zinc-700 mb-4 text-center">Catálogo de Productos ({catalog.length})</h3>
            <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-4">
                {catalog.map(p => <ObjectCard key={p.id} product={p} />)}
            </div>
        </div>
      )}

      <div className={`transition-opacity duration-300 ${!areUploadsComplete ? 'opacity-50 cursor-not-allowed pointer-events-none' : 'animate-fade-in'}`}>
        <div className="text-center mb-6">
          <h3 className="text-2xl font-bold text-zinc-800">Paso 3: Analizar Estilos</h3>
           {!areUploadsComplete && <p className="text-sm text-zinc-500">Sube una escena y al menos un producto para activar.</p>}
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 max-w-4xl mx-auto">
            {/* AI Recommends Card */}
            <div className={`bg-white border rounded-xl p-6 flex flex-col text-left ${!areUploadsComplete ? 'bg-zinc-50' : ''}`}>
                <h4 className="font-bold text-lg text-zinc-800">IA Recomienda un Estilo</h4>
                <p className="text-sm text-zinc-600 mt-1 mb-4 flex-grow">Deja que la IA analice tu espacio y productos para sugerirte el estilo de decoración perfecto y cómo encajar cada pieza.</p>
                <button
                    onClick={() => handleStartAnalysis('ai-recommends')}
                    disabled={!areUploadsComplete}
                    className="w-full bg-green-600 hover:bg-green-700 text-white font-bold py-2 px-4 rounded-lg transition-all shadow disabled:bg-zinc-300 disabled:cursor-not-allowed"
                >
                    Analizar con IA
                </button>
            </div>
            {/* User Validates Card */}
            <div className={`bg-white border rounded-xl p-6 flex flex-col text-left ${!areUploadsComplete ? 'bg-zinc-50' : ''}`}>
                <h4 className="font-bold text-lg text-zinc-800">Validar mi Estilo</h4>
                <p className="text-sm text-zinc-600 mt-1 mb-4 flex-grow">Elige un estilo y la IA te dirá si tus productos son compatibles, dándote consejos para lograr el look que quieres.</p>
                 <select
                      value={selectedStyle}
                      onChange={(e) => setSelectedStyle(e.target.value)}
                      disabled={!areUploadsComplete}
                      className="mb-4 w-full p-2 border border-zinc-300 rounded-md bg-white disabled:bg-zinc-100"
                  >
                      {DESIGN_STYLES.map(style => <option key={style} value={style}>{style}</option>)}
                  </select>
                <button
                    onClick={() => handleStartAnalysis('user-validates')}
                    disabled={!areUploadsComplete}
                    className="w-full bg-blue-600 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded-lg transition-all shadow disabled:bg-zinc-300 disabled:cursor-not-allowed"
                >
                    Validar con este Estilo
                </button>
            </div>
        </div>
      </div>
    </div>
  );

  const renderAnalysisAndGenerationStep = () => {
    const goodProductsCount = catalog.filter(p => p.analysis?.verdict === 'good').length;
    
    return (
        <div className="w-full animate-fade-in">
          <h2 className="text-2xl font-bold text-left mb-4 text-zinc-800">Elementos en tu Catálogo:</h2>
    
          {recommendedStyle && (
            <div className="recommended-style" style={{ marginBottom: '16px', padding: '8px', background: '#E6F4EA', borderRadius: '6px', fontWeight: 'bold' }}>
              Estilo recomendado por la IA: {recommendedStyle}
            </div>
          )}
    
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 mb-12">
            {catalog.map(p => (
                <ObjectCard 
                    key={p.id} 
                    product={p} 
                    isSelected={selectedProductIds.has(p.id)}
                    onClick={() => handleProductSelect(p.id)}
                />
            ))}
          </div>
    
          <div className="bg-zinc-50 border border-zinc-200 p-6 rounded-lg">
              <h3 className="text-2xl font-bold text-zinc-800 mb-6 text-center">Paso 4: Genera tus Diseños</h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                  {/* Product Selection */}
                  <fieldset className="space-y-2">
                      <legend className="font-semibold text-lg text-zinc-700 mb-2">Selección de Productos</legend>
                      <label className={`flex items-center gap-3 p-3 border rounded-md cursor-pointer transition-all ${productSelectionMode === 'manual' ? 'bg-blue-50 border-blue-400 ring-2 ring-blue-200' : 'hover:bg-zinc-100'}`}>
                          <input type="radio" name="product-selection" value="manual" checked={productSelectionMode === 'manual'} onChange={() => setProductSelectionMode('manual')} className="form-radio h-5 w-5 text-blue-600"/>
                          <span>Selección Manual ({selectedProductIds.size} seleccionados)</span>
                      </label>
                      <label className={`flex items-center gap-3 p-3 border rounded-md cursor-pointer transition-all ${productSelectionMode === 'ai' ? 'bg-blue-50 border-blue-400 ring-2 ring-blue-200' : 'hover:bg-zinc-100'}`}>
                          <input type="radio" name="product-selection" value="ai" checked={productSelectionMode === 'ai'} onChange={() => setProductSelectionMode('ai')} className="form-radio h-5 w-5 text-blue-600"/>
                          <span>Selección por IA ({goodProductsCount} producto(s) "BUENA IDEA")</span>
                      </label>
                  </fieldset>
                  
                  {/* Style Generation */}
                  <fieldset className="space-y-2">
                      <legend className="font-semibold text-lg text-zinc-700 mb-2">Control de Estilo por Versión</legend>
                      <label className={`flex items-center gap-3 p-3 border rounded-md cursor-pointer transition-all ${styleGenerationMode === 'creative-ai' ? 'bg-blue-50 border-blue-400 ring-2 ring-blue-200' : 'hover:bg-zinc-100'}`}>
                          <input type="radio" name="style-generation" value="creative-ai" checked={styleGenerationMode === 'creative-ai'} onChange={() => setStyleGenerationMode('creative-ai')} className="form-radio h-5 w-5 text-blue-600"/>
                          <span>IA Creativa (Variedad automática)</span>
                      </label>
                      <label className={`flex items-center gap-3 p-3 border rounded-md cursor-pointer transition-all ${styleGenerationMode === 'specific-styles' ? 'bg-blue-50 border-blue-400 ring-2 ring-blue-200' : 'hover:bg-zinc-100'}`}>
                          <input type="radio" name="style-generation" value="specific-styles" checked={styleGenerationMode === 'specific-styles'} onChange={() => setStyleGenerationMode('specific-styles')} className="form-radio h-5 w-5 text-blue-600"/>
                          <span>Asignar Estilo Específico</span>
                      </label>
                  </fieldset>
              </div>
              
              {/* Version Count & Specific Styles */}
              <div className="mt-6 border-t pt-6">
                  <div className="flex flex-col md:flex-row items-center gap-6">
                      <div className="flex-1">
                          <label htmlFor="versions" className="font-semibold text-lg text-zinc-700 mb-2 block">Número de Versiones</label>
                          <select id="versions" value={numberOfVersions} onChange={(e) => setNumberOfVersions(Number(e.target.value))} className="w-full p-2 border border-zinc-300 rounded-md bg-white">
                              <option value="1">1</option>
                              <option value="2">2</option>
                              <option value="3">3</option>
                              <option value="4">4</option>
                          </select>
                      </div>
                      {styleGenerationMode === 'specific-styles' && (
                          <div className="flex-1 w-full grid grid-cols-1 sm:grid-cols-2 gap-4">
                              {[...Array(numberOfVersions)].map((_, i) => (
                                  <div key={i}>
                                      <label htmlFor={`version-style-${i}`} className="text-sm font-medium text-zinc-600 mb-1 block">Estilo Versión {i+1}</label>
                                      <select id={`version-style-${i}`} value={versionStyles[i]} onChange={(e) => setVersionStyles(prev => ({...prev, [i]: e.target.value}))} className="w-full p-2 border border-zinc-300 rounded-md bg-white text-sm">
                                          {DESIGN_STYLES.map(style => <option key={style} value={style}>{style}</option>)}
                                      </select>
                                  </div>
                              ))}
                          </div>
                      )}
                  </div>
              </div>
              
              <div className="text-center mt-8">
                   <button
                      onClick={handleGenerationClick}
                      className="bg-blue-600 hover:bg-blue-700 text-white font-bold py-3 px-8 rounded-lg text-lg transition-all transform hover:scale-105 shadow-lg"
                  >
                      Generar {numberOfVersions} Diseño(s)
                  </button>
              </div>
          </div>
           <button onClick={handleReset} className="mt-8 mx-auto block text-zinc-500 hover:text-zinc-800">Empezar de nuevo</button>
        </div>
      );
  };

  const renderResultsStep = () => (
    <div className="w-full text-center animate-fade-in">
        <h2 className="text-3xl font-bold text-center mb-6 text-zinc-800">¡Aquí tienes tus diseños!</h2>
        <div className={`grid ${finalImages.length > 1 ? 'grid-cols-2' : 'grid-cols-1'} gap-6 mb-8`}>
            {finalImages.map((image, index) => (
                <div key={index} className="rounded-lg overflow-hidden shadow-lg border aspect-video bg-zinc-100">
                    <img src={image} alt={`Diseño generado ${index + 1}`} className="w-full h-full object-contain" />
                </div>
            ))}
        </div>
        <button onClick={handleReset} className="bg-blue-600 hover:bg-blue-700 text-white font-bold py-3 px-8 rounded-lg text-lg transition-transform transform hover:scale-105 shadow-lg">
            Crear un Nuevo Diseño
        </button>
    </div>
  );

  return (
    <div className="min-h-screen bg-zinc-50 flex flex-col items-center font-sans antialiased">
      <Header />
      <main className="flex-grow w-full max-w-7xl mx-auto p-4 md:p-6 flex flex-col items-center">
        {isLoading ? (
          <div className="flex flex-col items-center justify-center h-full text-center flex-grow">
            <Spinner />
            <p className="mt-6 text-xl text-zinc-700 font-semibold animate-fade-in">{loadingMessage}</p>
          </div>
        ) : (
          <>
            {currentStep === 'upload' && renderUploadStep()}
            {currentStep === 'analyze' && renderAnalysisAndGenerationStep()}
            {currentStep === 'results' && renderResultsStep()}
          </>
        )}
        {error && (
            <div className="mt-4 w-full max-w-3xl text-center bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded-lg" role="alert">
                <strong className="font-bold">Error: </strong>
                <span className="block sm:inline">{error}</span>
            </div>
        )}
      </main>

      {showAiConfirmModal && (
        <div className="fixed inset-0 bg-black bg-opacity-60 z-50 flex items-center justify-center p-4 animate-fade-in" onClick={() => setShowAiConfirmModal(false)}>
          <div className="bg-white rounded-xl shadow-2xl w-full max-w-4xl p-6 md:p-8 relative transform transition-all flex flex-col max-h-[90vh]" onClick={(e) => e.stopPropagation()}>
            <h3 className="text-2xl font-bold text-zinc-800 mb-2 flex-shrink-0">Confirmar Selección de IA</h3>
            <p className="text-zinc-600 mb-6 flex-shrink-0">La IA ha seleccionado los siguientes productos ("BUENA IDEA") para el diseño. ¿Deseas continuar?</p>
            <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4 mb-8 overflow-y-auto p-1">
              {catalog
                .filter(p => p.analysis?.verdict === 'good')
                .map(p => (
                  <ObjectCard key={p.id} product={p} />
                ))}
            </div>
            <div className="flex justify-end gap-4 mt-auto flex-shrink-0 border-t pt-4">
              <button 
                onClick={() => setShowAiConfirmModal(false)}
                className="bg-zinc-200 hover:bg-zinc-300 text-zinc-800 font-bold py-2 px-6 rounded-lg transition-colors"
              >
                Cancelar
              </button>
              <button 
                onClick={() => {
                  setShowAiConfirmModal(false);
                  handleGenerateFinalImage(); 
                }}
                className="bg-blue-600 hover:bg-blue-700 text-white font-bold py-2 px-6 rounded-lg transition-colors"
              >
                Confirmar y Generar
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default App;