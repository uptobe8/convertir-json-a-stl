/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
*/

import React from 'react';
import { ProductAnalysis } from '../types';

interface ObjectCardProps {
    product: ProductAnalysis;
    isSelected?: boolean;
    onClick?: () => void;
}

const getVerdictInfo = (verdict: 'good' | 'bad' | 'neutral' | undefined) => {
    switch(verdict) {
        case 'good': return {
            text: 'BUENA IDEA',
            className: 'text-green-600 bg-green-100'
        };
        case 'bad': return {
            text: 'MALA IDEA',
            className: 'text-red-600 bg-red-100'
        };
        case 'neutral': return {
            text: 'NEUTRAL',
            className: 'text-yellow-600 bg-yellow-100'
        };
        default: return {
            text: '—',
            className: 'text-zinc-500 bg-zinc-100'
        };
    }
}

const ObjectCard: React.FC<ObjectCardProps> = ({ product, isSelected, onClick }) => {
    const verdictInfo = product.analysis ? getVerdictInfo(product.analysis.verdict) : null;
    
    const cardClasses = `
        bg-white rounded-lg shadow-md overflow-hidden transition-all duration-300 border flex flex-col
        ${onClick ? 'cursor-pointer hover:shadow-xl hover:-translate-y-1' : ''}
        ${isSelected ? 'border-blue-500 shadow-xl scale-105 ring-2 ring-blue-300' : 'border-zinc-200'}
    `;

    return (
        <div className={cardClasses} onClick={onClick}>
            <div className="aspect-square w-full bg-zinc-100 flex items-center justify-center relative shrink-0">
                <img src={product.imageUrl} alt={product.name} className="w-full h-full object-contain" />
                {onClick && (
                    <div className={`absolute top-2 right-2 bg-white rounded-full h-6 w-6 flex items-center justify-center border-2 transition-all ${isSelected ? 'border-blue-500' : 'border-zinc-300'}`}>
                        {isSelected && <div className="h-3 w-3 bg-blue-500 rounded-full"></div>}
                    </div>
                )}
            </div>
            <div className="p-3 text-left flex-grow flex flex-col">
                {product.analysis && verdictInfo ? (
                     <div className="text-xs space-y-2 flex-grow flex flex-col">
                        <div className="mb-1">
                             <span className={`px-2 py-0.5 rounded-full font-bold text-xs ${verdictInfo.className}`}>
                                 {verdictInfo.text}
                             </span>
                        </div>
                        <p className="text-zinc-600"><span className="font-semibold text-zinc-800">Razón:</span> {product.analysis.reason || 'No disponible'}</p>
                        <p className="text-zinc-600 mt-auto pt-1"><span className="font-semibold text-zinc-800">Sugerencia:</span> {product.analysis.recommendation || 'No disponible'}</p>
                    </div>
                ) : (
                    <h4 className="text-sm font-semibold text-zinc-700 truncate self-center">{product.name}</h4>
                )}
            </div>
        </div>
    );
};

export default ObjectCard;