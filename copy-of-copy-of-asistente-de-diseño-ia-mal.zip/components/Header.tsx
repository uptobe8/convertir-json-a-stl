/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
*/
import React from 'react';

const Header: React.FC = () => {
  return (
    <header className="w-full p-4 text-center">
      <div className="flex items-center justify-center">
          <h1 className="text-5xl md:text-7xl font-extrabold tracking-tight bg-gradient-to-r from-zinc-900 via-[#d2dd00] to-zinc-700 bg-clip-text text-transparent">
            Diseña tu Espacio
          </h1>
      </div>
      <p className="mt-4 text-lg text-zinc-600 max-w-3xl mx-auto">
        Visualiza cualquier producto en tu propio espacio.
        <br />
        Sube una foto de tu habitación, tus productos, y deja que la IA cree el diseño perfecto.
      </p>
    </header>
  );
};

export default Header;