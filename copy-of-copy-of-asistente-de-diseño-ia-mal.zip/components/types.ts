/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
*/

export interface Product {
  id: string;
  name: string;
  file: File;
  imageUrl: string;
}

export interface AnalysisResult {
  verdict: 'good' | 'bad' | 'neutral';
  reason: string;
  recommendation: string;
}

// Combine Product and AnalysisResult for state management
export interface ProductAnalysis extends Product {
  analysis?: AnalysisResult;
}

// Define the steps of the application flow
export type AppStep = 'upload' | 'analyze' | 'results';

// Define the different modes for analysis and generation
export type AnalysisMode = 'ai-recommends' | 'user-validates' | null;
export type ProductSelectionMode = 'manual' | 'ai';
export type StyleGenerationMode = 'creative-ai' | 'specific-styles';
